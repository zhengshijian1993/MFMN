[![Build Status](https://travis-ci.org/SynthyAI/niqe.svg?branch=master)](https://travis-ci.org/SynthyAI/niqe)
# niqe
Package which implements the Natural Image Quality Evaluator (NIQE)
